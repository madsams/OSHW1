import java.util.concurrent.Semaphore;

public enum Region {
    SE, SW, NE, NW;

    private Semaphore semaphore = new Semaphore(1);
    private static Semaphore mutex = new Semaphore(1);

    static void downMutex(int carIndex) throws InterruptedException {
        mutex.acquire();
//        System.out.println("mutex locked by " + carIndex);
    }

    static void upMutex(int carIndex) {
        mutex.release();
//        System.out.println("mutex released by " + carIndex);
    }

    void down(int carIndex) {
        if (!semaphore.tryAcquire())
            upMutex(carIndex);
//        System.out.println(this + " locked by " + carIndex);
    }

    void up(int carIndex) {
        semaphore.release();
//        System.out.println(this + " released by " + carIndex);
    }
}
